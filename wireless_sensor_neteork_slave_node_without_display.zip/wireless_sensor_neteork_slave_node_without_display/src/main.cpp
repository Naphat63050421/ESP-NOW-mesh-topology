#include "esp_now.h"
#include "WiFi.h"
#include "NTC_TERMISTOR.h"


#define LENGTH_OFF_MACADDRS             6
#define LED_BTN_BLUE                    12
#define LED_BTN_YELLOW                  14
#define BUZZER_PIN                      18
#define BAUD_RATE                       115200

int buzzer_signal_count = 0;
int connector_master_node = 0;
int call_back_count = 0;
uint8_t macParts[6]; // Each part of the MAC Address is 2 characters
String recv_num_node = "node: ";
String recv_temperature_message = "00.0";
String device_mac_address = "";
// All MAC Address

uint8_t mac_addr_device[4][6] = {{0x64, 0xB7, 0x08, 0x80, 0xF2, 0x84},
                                {0x4C, 0x11, 0xAE, 0xE2, 0x53, 0x48},
                                {0xC8, 0xF0, 0x9E, 0x9C, 0x80, 0x1C},
                                {0x94, 0xB9, 0x7E, 0xE4, 0x93, 0xB4}};

unsigned long previousMillis = 0;
const long interval = 10000; // 10 seconds

// Structure example to send data
// Must match the receiver structure
char temperature_message_char[5];
typedef struct struct_message
{
  String num_node;
  float temperature_data;
  int fact_new_route;

} struct_message;

// Create a struct_message called myData
struct_message my_message;
// Create a Struct_message to hold data
struct_message receive_message;

struct_message route_message;

esp_now_peer_info_t peerInfo;

void convertStringToMacAddress(String message)
{
  // Split the MAC Address string into individual parts
  sscanf(message.c_str(), "%2X:%2X:%2X:%2X:%2X:%2X",
         &macParts[0], &macParts[1], &macParts[2],
         &macParts[3], &macParts[4], &macParts[5]);

  if (macParts[3] == mac_addr_device[1][3] && macParts[4] == mac_addr_device[1][4] && macParts[5] == mac_addr_device[1][5])
  {
    my_message.num_node = "node:1";
  }
  else if (macParts[3] == mac_addr_device[2][3] && macParts[4] == mac_addr_device[2][4] && macParts[5] == mac_addr_device[2][5])
  {
    my_message.num_node = "node:2";
  }
  else if (macParts[3] == mac_addr_device[3][3] && macParts[4] == mac_addr_device[3][4] && macParts[5] == mac_addr_device[3][5])
  {
    my_message.num_node = "node:3";
  }
}

void config_peer_esp_now(const uint8_t *macAddress)
{
  memcpy(peerInfo.peer_addr, macAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;
  connector_master_node = 1;    
}

void find_new_route()
{
  if (my_message.num_node == "node:1" && call_back_count == 1)
  {
    config_peer_esp_now(mac_addr_device[2]);
    if (esp_now_add_peer(&peerInfo) != ESP_OK)
    {
      Serial.println("Failed to add peer");
    }
    if (esp_now_add_peer(&peerInfo) == ESP_OK)
    {
      Serial.println("add peer OK");
    }
    if (esp_now_send(mac_addr_device[2], (uint8_t *)&my_message, sizeof(my_message)) == ESP_OK)
    {
      Serial.println("ESP-fine_new_route -> Send to mac_addr_node_2");
      digitalWrite(LED_BTN_YELLOW, HIGH);
      digitalWrite(LED_BTN_BLUE, LOW);
    }
    else
    {
      Serial.println("ESP-fine_new_route -> Can't Send to mac_addr_node_2");
      digitalWrite(LED_BTN_BLUE, HIGH);
      digitalWrite(LED_BTN_YELLOW, LOW);     
    }
  }
  else if (my_message.num_node == "node:1" && call_back_count == 2)
  {
    config_peer_esp_now(mac_addr_device[3]);
    if (esp_now_add_peer(&peerInfo) != ESP_OK)
    {
      Serial.println("Failed to add peer");
    }
    if (esp_now_add_peer(&peerInfo) == ESP_OK)
    {
      Serial.println("add peer OK");
    }
    if (esp_now_send(mac_addr_device[3], (uint8_t *)&my_message, sizeof(my_message)) == ESP_OK)
    {
      Serial.println("ESP-fine_new_route -> Send to mac_addr_node_3");
      digitalWrite(LED_BTN_YELLOW, HIGH);
      digitalWrite(LED_BTN_BLUE, LOW);
    }
    else
    {
      Serial.println("ESP-fine_new_route -> Can't Send to mac_addr_node_3");
      digitalWrite(LED_BTN_BLUE, HIGH);
      digitalWrite(LED_BTN_YELLOW, LOW);     
    }
  }
  else if 
}
// Callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) 
{
  if (status == ESP_NOW_SEND_SUCCESS)
  {
    call_back_count = 0;
    Serial.println("ESP_SEND_DATA_COMPLETE");
    digitalWrite(LED_BTN_YELLOW, HIGH);
    digitalWrite(LED_BTN_BLUE, LOW);
  }
  if(status == ESP_NOW_SEND_FAIL)
  {
    call_back_count++;
    Serial.println("ESP_CAN'T_SEND_DATA_COMPLETE -> find new route");
    digitalWrite(LED_BTN_BLUE, HIGH);
    digitalWrite(LED_BTN_YELLOW, LOW);
    find_new_route();
  }
}

// Callback when data is received
void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len)
{
  memcpy(&receive_message, incomingData, sizeof(receive_message));
  route_message.num_node = receive_message.num_node;
  route_message.temperature_data = receive_message.temperature_data;

  config_peer_esp_now(mac_addr_device[0]);
  if (esp_now_add_peer(&peerInfo) == ESP_OK)
  {
    if (esp_now_send(mac_addr_device[0], (uint8_t *)&my_message, sizeof(my_message)) == ESP_OK)
    {
      digitalWrite(LED_BTN_YELLOW, HIGH);
      digitalWrite(LED_BTN_BLUE, LOW);
    }
    else
    {
      Serial.println("ESP-route_message fail");
      digitalWrite(LED_BTN_BLUE, HIGH);
      digitalWrite(LED_BTN_YELLOW, LOW);
    }
  }
}

void setup() {
  //config adc mode and pin
  adc_config();

  pinMode(LED_BTN_BLUE, OUTPUT);
  pinMode(LED_BTN_YELLOW, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  Serial.begin(BAUD_RATE);

  // Set device as a Wi-Fi Station
  WiFi.mode(WIFI_STA);
  device_mac_address = WiFi.macAddress();
  convertStringToMacAddress(device_mac_address);

  // Init ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Once ESPNow is successfully Init, we will register for Send CB to
  // get the status of Trasnmitted packet
  esp_now_register_send_cb(OnDataSent);
  
  // Register peer
  config_peer_esp_now(mac_addr_device[0]);
  connector_master_node = 0;   
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }
  // Register for a callback function that will be called when data is received
  esp_now_register_recv_cb(OnDataRecv);
}

void loop()
{

  unsigned long currentMillis = millis();

  // Check if 10 seconds have passed
  if (currentMillis - previousMillis >= interval)
  {
    // Save the last time a new message was sent
    previousMillis = currentMillis;

    // Update the temperature data
    my_message.temperature_data = get_termistor_temperature();
    // Display information in Serial Monitor
    Serial.print("new_route: ");
    Serial.println(my_message.fact_new_route);
    Serial.print("num-node: ");
    Serial.println(my_message.num_node);
    Serial.print("temperature: ");
    Serial.println(my_message.temperature_data);
    if (connector_master_node == 1)
    {
      config_peer_esp_now(mac_addr_device[0]);  
      connector_master_node = 0;
    }
    esp_err_t result = esp_now_send(mac_addr_device[0], (uint8_t *)&my_message, sizeof(my_message));
  }
}
