#ifndef NTC_TERMISTOR_H_
#define NTC_TERMISTOR_H_




void adc_config();
float get_termistor_temperature();

#endif