#ifndef NTC_TERMISTOR_h
#define NTC_TERMISTOR_h

void read_termistor_adc_val();
int get_termistor_temperature();

#endif