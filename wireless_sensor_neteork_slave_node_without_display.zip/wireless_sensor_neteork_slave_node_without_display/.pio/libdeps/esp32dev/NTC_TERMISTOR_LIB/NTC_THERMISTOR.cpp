#define ADC_PIN                       32
#define LENGTH_OFF_MACADDRS           6
#define VOLTAGE                       3.3
#define BIT_RESOLUTION                4096
#define NTC_TERMISTOR_RESISTANCE      980
#define CONVERT_CELSIUS               273.15
#define NUM_VALUE_READDING            100

int termistor_buff_val[NUM_VALUE_READDING];
int termistor_adc_val[NUM_VALUE_READDING];
float output_voltage_buff[NUM_VALUE_READDING];
float thermistor_resistance[NUM_VALUE_READDING];
float therm_res_ln[NUM_VALUE_READDING];
float temperature_celsius[NUM_VALUE_READDING];

void read_termistor_adc_val()
{
  for (int i = 0; i < NUM_VALUE_READDING; i++)
  {
    termistor_adc_val[i] = analogRead(ADC_PIN);
  }
}

int get_termistor_temperature()
{
  float val_temperature = 0.0;
  for (int i = 0; i < NUM_VALUE_READDING; i++)
  {
    output_voltage_buff[i] = ((termistor_adc_val[i] * VOLTAGE) / BIT_RESOLUTION);
    thermistor_resistance[i] = ((VOLTAGE * (10.0 / output_voltage_buff[i])) - 10) * NTC_TERMISTOR_RESISTANCE; /* Resistance in ohms   */
    therm_res_ln[i] = log(thermistor_resistance[i]);
    temperature_celsius[i] = (1 / (0.001129148 + (0.000234125 * therm_res_ln[i]) + (0.0000000876741 * therm_res_ln[i] * therm_res_ln[i] * therm_res_ln[i]))) - CONVERT_CELSIUS; /* Temperature in Kelvin */ /* Temperature in degree Celsius */
    val_temperature += temperature_celsius[i];
  }
  val_temperature /= NUM_VALUE_READDING;
  return val_temperature;
}
void setup()
{
  Serial.begin(BAUD_RATE);
}
void loop()
{

}
