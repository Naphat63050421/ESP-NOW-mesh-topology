#include "TFT_eSPI.h"
#include "lvgl.h"
#include "ui.h"
#include "esp_now.h"
#include "WiFi.h"
#include <WiFiMulti.h>
#include <HTTPClient.h>
#include "NTC_TERMISTOR.h"
  
#define LENGTH_OF_MACADDRS              6
#define NUM_OF_MACADDRS                 4
#define LED_BTN_BLUE                    18   
#define LED_BTN_YELLOW                  19
#define BAUD_RATE                       115200

//define SCREEN
#define SCREEN_WIDTH                    320
#define SCREEN_HEIGHT                   240
#define ARRAY                           1000    // change variable to CHART_ARRAY
 
int buzzer_signal_count = 0;
int connector_master_node = 0;
uint8_t macParts[6]; // Each part of the MAC Address is 2 characters
String recv_num_node = "node: ";
String recv_temperature_message = "00.0";
String device_mac_address = "";
// All MAC Address

uint8_t mac_addr_device[NUM_OF_MACADDRS][LENGTH_OF_MACADDRS] = {{0x34, 0x85, 0x18, 0xB1, 0x62, 0xEE},
                                                                {0x4C, 0x11, 0xAE, 0xE2, 0x53, 0x48},
                                                                {0xC8, 0xF0, 0x9E, 0x9C, 0x80, 0x1C},
                                                                {0x94, 0xB9, 0x7E, 0xE4, 0x93, 0xB4}};

uint8_t task_sender_addr_device_node1[NUM_OF_MACADDRS - 1][LENGTH_OF_MACADDRS] = {{0x34, 0x85, 0x18, 0xB1, 0x62, 0xEC},  // master addr
                                                                                  {0xC8, 0xF0, 0x9E, 0x9C, 0x80, 0x1C},  // node2 addr
                                                                                  {0x94, 0xB9, 0x7E, 0xE4, 0x93, 0xB4}}; // node3 addr

uint8_t task_sender_addr_device_node2[NUM_OF_MACADDRS - 1][LENGTH_OF_MACADDRS] = {{0x34, 0x85, 0x18, 0xB1, 0x62, 0xEC},  // master addr
                                                                                  {0x4C, 0x11, 0xAE, 0xE2, 0x53, 0x48},  // node1 addr
                                                                                  {0x94, 0xB9, 0x7E, 0xE4, 0x93, 0xB4}}; // node3 addr

uint8_t task_sender_addr_device_node3[NUM_OF_MACADDRS - 1][LENGTH_OF_MACADDRS] = {{0x34, 0x85, 0x18, 0xB1, 0x62, 0xEC},  // master addr
                                                                                  {0x4C, 0x11, 0xAE, 0xE2, 0x53, 0x48},  // node1 addr
                                                                                  {0xC8, 0xF0, 0x9E, 0x9C, 0x80, 0x1C}}; // node2 addr

uint8_t task_sender_addr_device_node4[NUM_OF_MACADDRS - 1][LENGTH_OF_MACADDRS] = {{0x34, 0x85, 0x18, 0xB1, 0x62, 0xEC},  // master addr
                                                                                  {0x4C, 0x11, 0xAE, 0xE2, 0x53, 0x48},  // node1 addr
                                                                                  {0x94, 0xB9, 0x7E, 0xE4, 0x93, 0xB4}}; // node3 addr

uint8_t task_sender_addr_device_node5[NUM_OF_MACADDRS - 1][LENGTH_OF_MACADDRS] = {{0x34, 0x85, 0x18, 0xB1, 0x62, 0xEC},  // master addr
                                                                                  {0x4C, 0x11, 0xAE, 0xE2, 0x53, 0x48},  // node1 addr
                                                                                  {0xC8, 0xF0, 0x9E, 0x9C, 0x80, 0x1C}}; // node2 addr                                                                                  

unsigned long previousMillis = 0;
const long interval = 10000; // 10 seconds

char temperature_message_char[5];
typedef struct struct_message
{
  String num_node;
  float temperature_data;
  int fact_new_route;
 
} struct_message;
 
// Create a struct_message called myData
struct_message my_message;
// Create a Struct_message to hold data
struct_message receive_message;
 
struct_message route_message;
 
esp_now_peer_info_t peerInfo;

WiFiMulti WiFiMulti_network;

TFT_eSPI tft = TFT_eSPI();               // TFT instance
lv_disp_drv_t disp_drv;                  // LVGL display driver instance
static lv_disp_draw_buf_t draw_buf;      // LVGL buffer
static lv_color_t buf[SCREEN_WIDTH * 10]; // LVGL buffer array

// LVGL flush callback function
void my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p)
{
  uint32_t w = area->x2 - area->x1 + 1;
  uint32_t h = area->y2 - area->y1 + 1;
 
  tft.startWrite();
  tft.setAddrWindow(area->x1, area->y1, w, h);
  tft.pushColors((uint16_t *)color_p, w * h, true);
  tft.endWrite();
 
  lv_disp_flush_ready(disp_drv);
}
 
void convertStringToMacAddress(String message)
{
  // Split the MAC Address string into individual parts
  sscanf(message.c_str(), "%2X:%2X:%2X:%2X:%2X:%2X",
         &macParts[0], &macParts[1], &macParts[2],
         &macParts[3], &macParts[4], &macParts[5]);

  if (macParts[3] == mac_addr_device[1][3] && macParts[4] == mac_addr_device[1][4] && macParts[5] == mac_addr_device[1][5])
  {
    my_message.num_node = "node:1";
  }
  else if (macParts[3] == mac_addr_device[2][3] && macParts[4] == mac_addr_device[2][4] && macParts[5] == mac_addr_device[2][5])
  {
    my_message.num_node = "node:2";
  }
  else if (macParts[3] == mac_addr_device[3][3] && macParts[4] == mac_addr_device[3][4] && macParts[5] == mac_addr_device[3][5])
  {
    my_message.num_node = "node:3";
  }
}

void config_peer_esp_now(const uint8_t *macAddress)
{
  memcpy(peerInfo.peer_addr, macAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;
  connector_master_node = 1;  
}

void find_new_route()
{
  static int i;
  static int buzzer_count;
  static int node_peer = 0;

  if (my_message.num_node == "node:1")
  {
    if (node_peer == 0)
    {
      for (i = 1; i < NUM_OF_MACADDRS - 1; i++)
      {
        config_peer_esp_now(task_sender_addr_device_node1[i]);
        esp_err_t result = esp_now_add_peer(&peerInfo);
        if (result == ESP_OK)
        {
          Serial.print("add peer OK: ");
          Serial.println(i);
          node_peer = 1;
          break;
        }
        else
        {
          buzzer_count++;
          Serial.println("Failed to add peer");
        }
      }
      if (buzzer_count >= NUM_OF_MACADDRS - 1) {
        // beep
      }
      else {
        // do nothing
      }
    }
    esp_err_t result = esp_now_send(task_sender_addr_device_node1[i], (uint8_t *)&my_message, sizeof(my_message));
  }
  if (my_message.num_node == "node:2")
  {
    if (node_peer == 0)
    {
      for (i = 1; i < NUM_OF_MACADDRS - 1; i++)
      {
        config_peer_esp_now(task_sender_addr_device_node2[i]);
        esp_err_t result = esp_now_add_peer(&peerInfo);
        if (result == ESP_OK)
        {
          Serial.println("add peer OK");
          node_peer = 1;
          break;
        }
        else
        {
          buzzer_count++;
          Serial.println("Failed to add peer");
        }
      }
      if (buzzer_count >= NUM_OF_MACADDRS - 1) {
        // beep
      }
      else{
        // do nothing
      }
    }
    esp_err_t result = esp_now_send(task_sender_addr_device_node1[i], (uint8_t *)&my_message, sizeof(my_message));
  }
}

// Callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) 
{
  if (status == ESP_NOW_SEND_SUCCESS)
  {
    Serial.println("ESP_SEND_DATA_COMPLETE");
    digitalWrite(LED_BTN_YELLOW, HIGH);
    digitalWrite(LED_BTN_BLUE, LOW);
  }
  if(status == ESP_NOW_SEND_FAIL)
  {
    Serial.println("ESP_CAN'T_SEND_DATA_COMPLETE -> find new route");
    digitalWrite(LED_BTN_BLUE, HIGH);
    digitalWrite(LED_BTN_YELLOW, LOW);
    my_message.fact_new_route = 1;
    find_new_route();
  }
}
 
// Callback when data is received
void OnDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len)
{

  memcpy(&receive_message, incomingData, sizeof(receive_message));
  route_message.num_node = receive_message.num_node;
  route_message.temperature_data = receive_message.temperature_data;

  Serial.print("num-node: ");
  Serial.println(route_message.num_node);
  Serial.print("temperature: ");
  Serial.println(route_message.temperature_data);

  if (connector_master_node == 1)
  {
    config_peer_esp_now(mac_addr_device[0]);  
    connector_master_node = 0;
    esp_err_t result = esp_now_add_peer(&peerInfo);
    if (result == ESP_OK)
    {
      Serial.println("add peer OK");
    }
    else
    {
      Serial.println("Failed to add peer");
    }
  }
  if (esp_now_send(mac_addr_device[0], (uint8_t *)&route_message, sizeof(route_message)) == ESP_OK)
  {
    Serial.print("Route_succes");
  }
}

void setup()
{
  // config adc mode and pin
  adc_config();

  Serial.begin(BAUD_RATE);

  pinMode(LED_BTN_BLUE, OUTPUT);
  pinMode(LED_BTN_YELLOW, OUTPUT);

  // Set device as a Wi-Fi Station

  // We start by connecting to a WiFi network
  WiFiMulti_network.addAP("Test", "12345678");

  Serial.println();
  Serial.println();
  Serial.print("Waiting for WiFi... ");

  while (WiFiMulti_network.run() != WL_CONNECTED)
  {
    Serial.print(".");
    delay(500);
  }
  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());

  delay(500);
  WiFi.mode(WIFI_STA);
  device_mac_address = WiFi.macAddress();
  convertStringToMacAddress(device_mac_address);

  // Init ESP-NOW
  if (esp_now_init() != ESP_OK)
  {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // Once ESPNow is successfully Init, we will register for Send CB to
  // get the status of Trasnmitted packet
  esp_now_register_send_cb(OnDataSent);

  // Register peer
  config_peer_esp_now(mac_addr_device[0]);
  connector_master_node = 0;
  if (esp_now_add_peer(&peerInfo) != ESP_OK)
  {
    Serial.println("Failed to add peer");
    return;
  }
  // Register for a callback function that will be called when data is received
  esp_now_register_recv_cb(OnDataRecv);

  // Initialize TFT display
  tft.begin();
  tft.setRotation(3); // Adjust rotation as needed

  // Initialize LVGL
  lv_init();
  lv_disp_draw_buf_init(&draw_buf, buf, NULL, SCREEN_WIDTH * 10);
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = SCREEN_WIDTH;
  disp_drv.ver_res = SCREEN_HEIGHT;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);
  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  lv_indev_drv_register(&indev_drv);
  // Call UI initialization function
  ui_init();
}

void loop()
{
  char temp_t[10];
  unsigned long currentMillis = millis();
  static int count_position_array;
  static lv_coord_t ui_Chart1_series_1_array[ARRAY];
  if (currentMillis - previousMillis >= interval)
  {
    previousMillis = currentMillis;

    my_message.temperature_data = get_termistor_temperature();
    Serial.print("new_route: ");
    Serial.println(my_message.fact_new_route);
    Serial.print("num-node: ");
    Serial.println(my_message.num_node);
    Serial.print("temperature: ");
    Serial.println(my_message.temperature_data);

    lv_arc_set_value(ui_Arc1, my_message.temperature_data);
    sprintf(temp_t, "%.1f°C", my_message.temperature_data);
    lv_label_set_text(ui_Label2, temp_t);

    lv_chart_series_t *ui_Chart1_series_1 = lv_chart_add_series(ui_Chart1, lv_color_hex(0x808080), LV_CHART_AXIS_PRIMARY_Y);
    if (count_position_array <= ARRAY - 1)
    {
      count_position_array++;
      ui_Chart1_series_1_array[count_position_array] = get_termistor_temperature();
      lv_chart_set_point_count(ui_Chart1, count_position_array);
      lv_chart_set_ext_y_array(ui_Chart1, ui_Chart1_series_1, ui_Chart1_series_1_array);
    }
    else
    {
      count_position_array = 0;
    }
    if (connector_master_node == 1)
    {
      config_peer_esp_now(mac_addr_device[0]);
      connector_master_node = 0;
    }
    esp_err_t result = esp_now_send(mac_addr_device[0], (uint8_t *)&my_message, sizeof(my_message));
    if (WiFi.status() == WL_CONNECTED)
    {
      HTTPClient http;
      String url = "https://script.google.com/macros/s/AKfycbxGCVKYkx2bhA3AeoHsJvVpXU3Fzv9C9W3z4RJVXPsTpHqAPGFL8JaND1IJm5y6_wrd/exec?device_node=" + my_message.num_node + "&value="  + String(my_message.temperature_data);
      Serial.println("Making a request");
      http.begin(url.c_str()); // Specify the URL and certificate
      http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
      int httpCode = http.GET();
      String payload;
      if (httpCode > 0)
      { // Check for the returning code
        payload = http.getString();
        Serial.println(httpCode);
        Serial.println(payload);
      }
      else
      {
        Serial.println("Error on HTTP request");
      }
      http.end();
    }
  }
  lv_task_handler();
}

